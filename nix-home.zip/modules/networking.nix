{ config, pkgs, ... }:

#Networking Module
{
  
  # ─────────────────────────────────────────────
  # Bluetooth
  # ─────────────────────────────────────────────
  hardware.bluetooth = {
      enable = true;
      powerOnBoot = true;
      settings = {
        General = {
          Enable = "Source,Sink,Media,Socket";
          Experimental = true; # Ayuda con adaptadores caprichosos
        };
      };
    };

  services.blueman.enable = true;
  
  hardware.enableAllFirmware = true;

  # ─────────────────────────────────────────────
  # Network
  # ─────────────────────────────────────────────

  networking.hostName = "nixos";

  networking.networkmanager.enable = true;

  #  networking.firewall = {
  # #   allowedTCPPorts = [
  # #     25565
  # #   ];
  #   allowedUDPPorts = [
  #     49983
  #     50509
  #   ];
  # };
  
  # ─────────────────────────────────────────────
  # Timezone
  # ─────────────────────────────────────────────

  time.timeZone = "America/Phoenix";
  #time.timeZone = "America/Mexico_City";

  # ─────────────────────────────────────────────
  # Locale
  # ─────────────────────────────────────────────

  i18n.defaultLocale = "en_US.UTF-8";

  # ─────────────────────────────────────────────
  # Keyboard
  # ─────────────────────────────────────────────

  services.xserver.xkb = {
    layout = "us";
    variant = "";
  };
}